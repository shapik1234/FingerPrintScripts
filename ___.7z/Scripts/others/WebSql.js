﻿function websql(name, version) {
			var indexedDb = window.indexedDB || window.webkitIndexedDB || window.mozIndexedDB || window.msIndexedDB;
			var IDBTransaction = window.IDBTransaction || window.webkitIDBTransaction;
			var db = null;
			var request = indexedDb.open(name, version);
			request.onsuccess = function (e)
			{
				db = e.target.result;
				alert(JSON.stringify(db));
				var transaction = db.transaction("hash");
				alert(transaction)
				var objectStore = transaction.objectStore("hash");
				alert(JSON.stringify(objectStore))
				var request = objectStore.get(1);
				request.onsuccess = function (e)
				{
					alert("Name for id 1 " + JSON.stringify(request.result));
				};
				request.onerror = function (e)
				{
					alert("error, Name for id 1 " + JSON.stringify(e));
				};
			}
			request.onerror = function (e)
			{
				alert("onerror:" + e.target.errorCode);
			};
			request.onupgradeneeded = function (e)
			{
				var db = e.currentTarget.result;
				//var objectStore = db.createObjectStore("hash", { autoIncrement : true });
				//objectStore.add("1234509");
				//alert(JSON.stringify(objectStore));
			};
		}
		//alert(1);
		//websql("evercookie3", 1);