﻿<script>
		var fs = null;
		// Check for the various File API support.
		if (window.File && window.FileReader && window.FileList && window.Blob) {
			// Initiate filesystem on page load.
			initFS();
		} else {
			alert('The File APIs are not fully supported in this browser.');
		}

		function onOk(filesystem)
		{
			fs = filesystem;
		}

		function errorHandler(e)
		{
			var msg = '';
			switch (e.code)
			{
				case FileError.QUOTA_EXCEEDED_ERR:
					msg = 'QUOTA_EXCEEDED_ERR';
					break;
				case FileError.NOT_FOUND_ERR:
					msg = 'NOT_FOUND_ERR';
					break;
				case FileError.SECURITY_ERR:
					msg = 'SECURITY_ERR';
					break;
				case FileError.INVALID_MODIFICATION_ERR:
					msg = 'INVALID_MODIFICATION_ERR';
					break;
				case FileError.INVALID_STATE_ERR:
					msg = 'INVALID_STATE_ERR';
					break;
				default:
					msg = 'Unknown Error';
					break;
			};
			console.log('Error: ' + msg);
		}

		function initFS()
		{
			window.URL = window.URL || window.webkitURL;
			window.requestFileSystem = window.requestFileSystem || window.webkitRequestFileSystem;
			window.storageInfo = window.storageInfo || window.webkitStorageInfo;

			window.storageInfo.requestQuota(PERSISTENT, 1024,
				function (grantedBytes) {
					window.requestFileSystem(window.PERSISTENT, grantedBytes, function (f) { fs = f; }, errorHandler);
				}, errorHandler);

			window.requestFileSystem(window.PERSISTENT, 1024, function (f) { fs = f; }, errorHandler);

			//chrome.system.storage.getInfo(cb);
		}

		function writeFile(path, content){
			fs.root.getFile('log1.txt', {create: true}, function(fileEntry) {
				fileEntry.createWriter(function(fileWriter) {
					fileWriter.onwriteend = function(e) {
						console.log('Write completed.');
					};
					fileWriter.onerror = function(e) {
						console.log('Write failed: ' + e.toString());
					};

					var bb = new window.WebKitBlobBuilder();
					bb.append(content);
					fileWriter.write(bb.getBlob('text/plain'));
				}, errorHandler);

				fs.root.getDirectory(path, {create: true}, function(dirEntry) {
					fileEntry.moveTo(dirEntry);
					console.log('in');
				}, errorHandler);
			}, errorHandler);
		}
	</script>