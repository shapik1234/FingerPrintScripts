﻿function sqlite() {
			if (window.openDatabase)
			{
				alert("openDatabase")
				var database = window.openDatabase("sqlite_evercookie", "", "evercookie", 1024 * 1024);
				var name = "dbfpkey_ec2";
				var value = "098776";

				database.transaction(
				function (tx)
				{
					tx.executeSql("SELECT value FROM cache WHERE name=?", [name],
						function (tx, result1)
						{
							if (result1.rows.length >= 1)
							{
								alert(result1.rows.item(0).value);
							} else
							{
								alert("fail");
							}
						}, function (tx, err) { alert(err); });
				});
				/*
				database.transaction(function (tx)
				{
				tx.executeSql("CREATE TABLE IF NOT EXISTS cache(" +
				"id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
				"name TEXT NOT NULL, " +
				"value TEXT NOT NULL, " +
				"UNIQUE (name)" +
				")", [], function (tx, rs) { }, function (tx, err) { });
				tx.executeSql("INSERT OR REPLACE INTO cache(name, value) " +
				"VALUES(?, ?)",
				[name, value], function (tx, rs) { }, function (tx, err) { });
				});
				*/
			}

			function f(name, value)
			{
				alert("globalStorage");
				var globalStorage = window.globalStorage;
				if (globalStorage)
				{
					alert("globalStorage1");
					var host = this.getHost();
					try
					{
						alert(globalStorage[host]);
						/*if (value !== undefined)
						{
						globalStorage[host][name] = value;
						}
						else
						{
						alert(globalStorage[host][name]);
						}*/
					} catch (e) { alert(e); }
				}
			}
		}