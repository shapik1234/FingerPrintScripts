﻿var BrowserDetect = {
	init: function () {
		this.browser = this.searchString(this.dataBrowser) || "an unknown browser";
		this.version = this.searchVersion(navigator.userAgent) || this.searchVersion(navigator.appVersion) || "an unknown version";
		this.OS = this.searchString(this.dataOS) || "an unknown OS"
	},
	searchString: function (d) {
		for (var a = 0; a < d.length; a++) {
			var b = d[a].string;
			var c = d[a].prop;
			this.versionSearchString = d[a].versionSearch || d[a].identity;
			if (b && b.indexOf(d[a].subString) != -1) {
				return d[a].identity
			}
			else if (c) {
				return d[a].identity
			}
		}
	},
	searchVersion: function (b) {
		var a = b.indexOf(this.versionSearchString);
		if (a != -1) {
			return parseFloat(b.substring(a + this.versionSearchString.length + 1));
		}
	},
	dataBrowser:
	[
		{ string: navigator.userAgent, subString: "OPR", identity: "Opera", versionSearch: "OPR" },
		{ string: navigator.userAgent, subString: "Opera", identity: "Opera", versionSearch: "Version" },
		{ string: navigator.userAgent, subString: "YaBrowser", identity: "Yandex.Browser", versionSearch: "YaBrowser" },
		{ string: navigator.userAgent, subString: " YI", identity: "Yandex.Browser", versionSearch: "Chrome" },
		{ string: navigator.userAgent, subString: "Chrome", identity: "Chrome" },
		{ string: navigator.userAgent, subString: "OmniWeb", identity: "OmniWeb", versionSearch: "OmniWeb/" },
		{ string: navigator.vendor, subString: "Apple", identity: "Safari", versionSearch: "Version" },
		{ prop: window.opera, identity: "Opera" },
		{ string: navigator.vendor, subString: "iCab", identity: "iCab" },
		{ string: navigator.vendor, subString: "KDE", identity: "Konqueror" },
		{ string: navigator.userAgent, subString: "Firefox", identity: "Firefox" },
		{ string: navigator.vendor, subString: "Camino", identity: "Camino" },
		{ string: navigator.userAgent, subString: "Netscape", identity: "Netscape" },
		{ string: navigator.userAgent, subString: "MSIE", identity: "Explorer", versionSearch: "MSIE" },
		{ string: navigator.userAgent, subString: "Trident", identity: "Explorer", versionSearch: "rv" },
		{ string: navigator.userAgent, subString: "Gecko", identity: "Mozilla", versionSearch: "rv" },
		{ string: navigator.userAgent, subString: "Mozilla", identity: "Netscape", versionSearch: "Mozilla" }
	],
	dataOS:
	[
		{ string: navigator.platform, subString: "Win", identity: "Windows" },
		{ string: navigator.platform, subString: "Mac", identity: "Mac" },
		{ string: navigator.userAgent, subString: "iPhone", identity: "iPhone/iPod" },
		{ string: navigator.platform, subString: "Linux", identity: "Linux" }
	]
};
BrowserDetect.init();
