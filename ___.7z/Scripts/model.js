﻿function _slCallback(key, value) {
	Fingerprint._in0.slCallback(key, value);
}
function _slLoaded(sender, args) {
	Fingerprint.slLoaded(sender, args);
}
function _slFailed(sender, args) {
	Fingerprint.slFailed(sender, args);
}
var Fingerprint = {
	_fl: { data: null },
	_js: { plugins: null },
	_jsdd: {},
	_sl: {data: null },
	_custom: { params: null, hash: null, data: null },
	_in0: { getGeo: false, debug: false, timeout: 0, baseUrl: "", filesUrl: "", flCallback: null, flHost: null, slCallback: null, slHost: null }
};
Fingerprint.init = function (baseUrl, filesUrl, flSet, slSet, getGeo, debug) {
	this._fl.data = new Array();
	this._sl.data = new Array();
	this._js.plugins = new Array();
	this._custom.data = new Array();
	this._custom.params = new Array();

	if (getGeo != undefined) {
		this._in0.getGeo = getGeo;
	}

	if (debug != undefined) {
		this._in0.debug = debug;
	}

	this._in0.baseUrl = baseUrl;
	this._in0.filesUrl = filesUrl;
	this._in0.flCallback = flSet.callback || this.flCallback;
	this._in0.flHost = flSet.host;
	this._in0.slCallback = slSet.callback || this.slCallback;
	this._in0.slHost = slSet.host;

	this.createFlash(flSet.host);
	this.createSilverlight(slSet.host, this._in0.debug);
	this.getParams(this._custom);
}
Fingerprint.createFlash = function (host) {
	try {
		swfobject.embedSWF(this._in0.filesUrl + "fp.swf?" + new Date().getTime(), host, "0px", "0px", "9.0.0", this._in0.filesUrl + "expressInstall.swf", { callbackName: "Fingerprint._in0.flCallback" }, { allowscriptaccess: "always" }, null);
	} catch (e) {
		console.log("Flash failed!");
	}
}
Fingerprint.createSilverlight = function (host, debug) {
	var sl =
		'<object data="data:application/x-silverlight-2," type="application/x-silverlight-2" width="0px" height="0px" id="slPlugin">' +
			'<param name="background" value="white" />' +
			'<param name="enableHtmlAccess" value="true" />' +
			'<param name="source" value="{0}" />' +
			'<param name="initParams" value="callbackName=_slCallback" />' +
			'<param name="onLoad" value="_slLoaded" />' +
			'<param name="onError" value="_slFailed" />' +
		'</object>';

	var parent = document.getElementById(host);
	parent.innerHTML = sl.replace("{0}", this._in0.filesUrl + (debug ? "Debug/" : "") + "fp5.xap");
}
Fingerprint.gatherAll = function () {
	this.gatherJs();
	this.gatherJsDd();
}
Fingerprint.gatherJs = function () {
	this._js.BrowserDetect = { 'browser': BrowserDetect.browser, 'version': BrowserDetect.version, 'OS': BrowserDetect.OS };
	this._js.userAgent = navigator.userAgent || null;
	this._js.appName = navigator.appName || null;
	this._js.appCodeName = navigator.appCodeName || null;
	this._js.appVersion = navigator.appVersion || null;
	this._js.appMinorVersion = navigator.appMinorVersion || null;
	this._js.buildId = navigator.buildID || null;
	this._js.platform = navigator.platform || null;
	this._js.cpuClass = navigator.cpuClass || null;
	this._js.osCpu = navigator.oscpu || null;
	this._js.product = navigator.product || null;
	this._js.productSub = navigator.productSub || null;
	this._js.vendor = navigator.vendor || null;
	this._js.vendorSub = navigator.vendorSub || null;
	this._js.language = navigator.language || null;
	this._js.userLanguage = navigator.userLanguage || null;
	this._js.browserLanguage = navigator.browserLanguage || null;
	this._js.systemLanguage = navigator.systemLanguage || null;
	var doNotTrack = navigator.doNotTrack || navigator.msDoNotTrack;
	this._js.doNotTrack = (doNotTrack != null && doNotTrack != 'undefined');
	this._js.javaEnabled = navigator.javaEnabled() || false;
	this._js.geolocation = null;
	this._in0.timeout = 300;
	if (this._in0.getGeo && navigator.geolocation) {
		this._in0.timeout = 1000;
		navigator.geolocation.getCurrentPosition(function (position) {
			Fingerprint._js.geolocation = position.coords.latitude + "," + position.coords.longitude;
		}, function (error) {
			try {
				console.log("geolocation.getCurrentPosition is failed: " + error.message + "(" + error.code + ")");
			} catch (e) {}
		}, { timeout: Fingerprint._in0.timeout });
	}
	this._js.cookiesEnabled = navigator.cookieEnabled || false;
	// TODO: try to create new cookie and read it back, if stored value is read keep true value for 'Fingerprint._js.cookiesEnabled' otherwise change to false.
	//
	this._js.webStorage = window.localStorage != 'undefined' || false;
	this._js.plugins = this.getPlugins();
}
Fingerprint.gatherJsDd = function () {
	this._jsdd.screen = screen.width + "x" + screen.height;
	this._jsdd.available = this.iff(screen.availWidth, screen.availWidth + "x" + screen.availHeight, null);
	this._jsdd.windowPosition = null;
	if (window.screenX) {
		this._jsdd.windowPosition = window.screenX + "x" + window.screenY;
	} else if (window.screenTop) {
		this._jsdd.windowPosition = window.screenTop + "x" + window.screenLeft;
	}
	this._jsdd.windowOuter = window.outerWidth + "x" + window.outerHeight;
	this._jsdd.windowInner = window.innerWidth + "x" + window.innerHeight;
	this._jsdd.client = document.documentElement.clientWidth + "x" + document.documentElement.clientHeight;
	this._jsdd.colorDepth = screen.colorDepth;
	this._jsdd.pixelDepth = screen.pixelDepth;
	this._jsdd.pixelRatio = window.devicePixelRatio;
	this._jsdd.fontSmoothing = screen.fontSmoothingEnabled || null;
	this._jsdd.bufferDepth = screen.bufferDepth || null;
	this._jsdd.deviceDpi = this.iff(screen.deviceXDPI, screen.deviceXDPI + "x" + screen.deviceYDPI, null);
	this._jsdd.logicalDpi = this.iff(screen.logicalXDPI, screen.logicalXDPI + "x" + screen.logicalYDPI, null);
	this._jsdd.systemDpi = this.iff(screen.systemXDPI, screen.systemXDPI + "x" + screen.systemYDPI, null);
	this._jsdd.updateInterval = screen.updateInterval || null;
}
Fingerprint.getPlugins = function () {
	var plugins = null;
	if (navigator.plugins) {
		plugins = new Array();
		var np = navigator.plugins;
		for (var i = 0; i < np.length; i++) {
			plugins[i] = {};
			plugins[i].name = np[i].name;
			plugins[i].description = np[i].description;
			plugins[i].file = np[i].filename;
			plugins[i].items = new Array();
			for (var n = 0; n < np[i].length; n++) {
				plugins[i].items[n] = {};
				plugins[i].items[n].description = np[i][n].description;
				plugins[i].items[n].type = np[i][n].type;
				plugins[i].items[n].suffixes = np[i][n].suffixes;
			}
		}
		plugins.sort(function (a, b) {
			if (a.name < b.name) return -1;
			if (a.name > b.name) return 1;
			return 0;
		});
	}

	if (plugins == null) {
		var plugin_list = {
			flash: 'ShockwaveFlash.ShockwaveFlash.1',
			pdf: 'AcroPDF.PDF',
			silverlight: 'AgControl.AgControl',
			quicktime: 'QuickTime.QuickTime'
		}

		var p = 0;
		plugins = new Array();
		for (var plugin in plugin_list) {
			var version = Fingerprint.msieDetect(plugin_list[plugin]);
			if (version !== false) {
				plugins[p] = {};
				plugins[p].name = plugin_list[plugin];
				plugins[p].description = version;
				p++;
			}
			/*if (version) {
			var version_reg_val = version_reg.exec(version);
			plugins[plugin] = (version_reg_val && version_reg_val[0]) || '';
			}*/
		}

		if (navigator.javaEnabled()) {
			plugins[p] = {};
			plugins[p].name = 'Java';
		}

		// in IE, things are much harder; we use PluginDetect to get less
		// information (only the plugins listed below & their version numbers)
		/*
		var pp = new Array();
		pp[0] = "Java";
		pp[1] = "QuickTime";
		pp[2] = "DevalVR";
		pp[3] = "Shockwave";
		pp[4] = "Flash";
		pp[5] = "WindowsMediaplayer";
		pp[6] = "Silverlight";
		pp[7] = "VLC";

		var version;
		for (p in pp) {
		version = PluginDetect.getVersion(pp[p]);
		if (version)
		plugins += pp[p] + " " + version + "; "
		}
		plugins += ieAcrobatVersion();
		}
		*/
	}

	return plugins;
}
Fingerprint.msieDetect = function(name) {
	try {
		var axObj = new ActiveXObject(name);
		try {
			return axObj.GetVariable('$version');
		} catch(e) {
			try {
				return axObj.GetVersions();
			} catch (e) {
				try {
					var version;
					for (var i = 1; i < 9; i++) {
						if (axObj.isVersionSupported(i + '.0')) {
							version = i;
						}
					}
					return version || true;
				} catch (e) {
					return true;
				}
			}
		}
	} catch(e) {
		return false;
	}
}
Fingerprint.finalize = function (id, encodeFunc, onComplete, onFail, onDebug, dontSend) {
	setTimeout(function () {
		var data = Fingerprint.asJSON();
		if (onDebug != undefined) {
			onDebug(data);
		}

		if (dontSend == undefined || !dontSend) {
			Fingerprint.send(id, encodeFunc, data, onComplete, onFail);
		}
	}, this._in0.timeout);
	this._in0.timeout = 0;
}
Fingerprint.send = function (id, encodeFunc, data, onComplete, onFail) {
	var headers = {
		'Content-Type': 'application/x-www-form-urlencoded'
	};

	var transports = [
		function () { return new XMLHttpRequest(); },
		function () { return new ActiveXObject('Msxml2.XMLHTTP'); },
		function () { return new ActiveXObject('Microsoft.XMLHTTP'); }
	];

	var transport;
	for (var i = 0; i < transports.length; i++) {
		transport = transports[i];
		try {
			transport = transport();
			break;
		} catch (e) { }
	}

	if (transport) {
		var url = this._in0.baseUrl + ((id !== undefined && id[0] === '"') ? id.substring(1, id.length-1) : id) + ".ashx";
		transport.open("POST", url, true);

		for (var name in headers) {
			transport.setRequestHeader(name, headers[name]);
		}

		transport.onreadystatechange = function () {
			if (transport.readyState === 4) {
				if (transport.status === 200) {
					if (onComplete) {
						onComplete(transport.responseText);
					}
				} else {
					if (onFail) {
						onFail(transport.statusText, transport.status);
					}
				}
			}
		};

		transport.send((encodeFunc != null) ? encodeFunc(data) : data);
	}

	return false;
}
Fingerprint.selectId = function (best, all) {
	if (BrowserDetect.browser != "Chrome" && all.lsoData != undefined) {
		return all.lsoData;
	}
	return best;
}
Fingerprint.asJSON = function () {
	var safe = this._in0;
	delete this._in0;
	var data = JSON.stringify(this);
	this._in0 = safe;
	return data;
}
Fingerprint.flCallback = function (key, value) {
	Fingerprint._fl.data.push({ key: key, value: value });
}
Fingerprint.slCallback = function (key, value) {
	Fingerprint._sl.data.push({ key: key, value: value });
}
Fingerprint.slLoaded = function (sender, args) {
	if (Fingerprint._in0.slHost) {
		var ctrl = document.getElementById(Fingerprint._in0.slHost);
		if (ctrl) {
			ctrl.innerHTML = "";
		}
	}
	delete sender;
}
Fingerprint.slFailed = function (sender, args) {
	// TODO: Implement something another!
	try { 
		console.log("Silverlight failed"); 
	} catch (e) {}
}
Fingerprint.addCustom = function (key, value) {
	Fingerprint._custom.data.push({ key: key, value: value });
}
Fingerprint.getParams = function (data) {
	var match,
		pl = /\+/g,
		search = /([^&=]+)=?([^&#]*)/g,
		decode = function (s) { return decodeURIComponent(s.replace(pl, " ")); },
		query = window.location.search.substring(1);

	while (match = search.exec(query)) {
		data.params.push({ key: decode(match[1]), value: decode(match[2]) });
	}
	data.hash = window.location.hash.substring(1);
}
Fingerprint.iff = function (condition, truevalue, falsevalue) {
	return (condition) ? truevalue : falsevalue;
}
