﻿var fppixel = {
	name: "fppixel.js",
	key: "dbfpkey_ec",
	url: null,
	engineUrl: null,
	ec: null,
	selfStart: true,
	options: {},
	init: function (encodeFunc, onComplete, onFail, onDebug) {
		this.ec = new evercookie({ authPath: false, pngPath: false, etagPath: false, cachePath: false, baseurl: this.url + "zc/", tests: 3 });
		this.encodeFunc = encodeFunc || null;
		this.onComplete = onComplete || this.complete;
		this.onFail = onFail || null;
		this.onDebug = onDebug || null;
	},
	start: function (engineUrl, callback) {
		fppixel.engineUrl = engineUrl;
		fppixel.ec.get(fppixel.key, callback || fppixel.callbackFunc, 1);
	},
	complete: function (hash) {
		fppixel.ec.set(fppixel.key, hash);
	},
	callbackFunc: null,
	encodeFunc: null,
	onComplete: null,
	onFail: null,
	onDebug: null,
	loadScriptsSync: function (scripts, callback) {
		if (this.url === null) {
			this.url = document.getElementById(this.name).src.replace(this.name, "");
		}

		if (scripts.length === 0 && callback !== undefined) {
			callback();
		} else {
			var ref = document.createElement('script');
			ref.setAttribute("type", "text/javascript");
			ref.setAttribute("src", this.url + scripts[0]);

			var func = function () { scripts.shift(); fppixel.loadScriptsSync(scripts, callback); }
			if (ref.addEventListener) {
				ref.addEventListener("load", func, false);
			}
			else if (ref.readyState) {
				ref.onreadystatechange = func;
			}

			if (ref != undefined) {
				document.getElementsByTagName("head")[0].appendChild(ref);
			}
		}
	}
};
// Load scripts
fppixel.loadScriptsSync(
	["swfobject.js", "base64.js", "BrowserDetect.js", "zc/zc.js", "model.js"], 
	fppixel.selfStart ? function(){ fppixel.init(window.encode); } : undefined);
